#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int height;

    //Rejects unacceptable height
    do
    {
        height = get_int("Height: ");
    }
    while (height < 1 || height > 8);

    //checks condition
    if (height > 0 || height < 9) {
        int counter = 0;
        for (int row=0; row<height; row++)
        {
            if (counter != height)
            {
               //prints starting space
                for (int spaces = (height-1) - counter; spaces > 0; spaces--)
                {
                    printf(" ");
                }
                //prints first urdle
                for (int hashes = 0; hashes <= counter; hashes++)
                {
                    printf("#");
                }

                //creates middle space
                printf("  ");

                //creates second hurdle
                for (int hashes = 0; hashes <= counter; hashes++)
                {
                    printf("#");
                }

                printf("\n");
                counter++;
            }
        }
    }
}