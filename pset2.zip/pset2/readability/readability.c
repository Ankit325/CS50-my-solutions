#include<stdio.h>
#include<string.h>
#include<cs50.h>
#include<math.h>

int main()
{
    int n,i,words=0,letters=0,sentences=0;
    float L,S,index;
    string s=get_string("Text:");
    //printf("%c",s[0]);
    n=strlen(s);
    words=1;
    for(i=0;i<n;i++)
    {
        if((s[i]>='A' && s[i]<='Z') || (s[i]>='a' && s[i]<='z'))
        {
            letters++;
        }
        if(s[i]==' ' && s[i+1]!=' ')
        {
            words++;
        }
        if(s[i]=='.' || s[i]=='!' || s[i]=='?')
        {
            sentences++;
        }
    }
    //printf("Letters=%d\nWords=%d\nSentences=%d\n",letters,words,sentences);
    L=((float)letters/words)*100;
    S=((float)sentences/words)*100;
   // printf("L=%f  S=%f",L,S);
    index = 0.0588 * L - 0.296 * S - 15.8;
    if(index<1){
        printf("Before Grade 1\n");
    }
    else if(index>16){
        printf("Grade 16+\n");
    }
    else{
        printf("\nGrade %d\n",(int)round(index));
    }
    return 0;

}