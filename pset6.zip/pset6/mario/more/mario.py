

#checks n
while(True):
        n = input("Height: ")
        if(n.isalpha()):
            continue
        n=int(n)

        if(n<1 or n>9):
            continue
        if(n>0 and n<9):
            break
#Entry check
if(n>0 and n<9):
    s=n-1
    for i in range(n):
        #prints stairs
        for j in range(s):
            print(" ",end="")
        for j in range(i+1):
            print("#",end="")
        #prints middle space
        print("  ",end="")
        #prints  downside ladder
        for j in range(i+1):
            print("#",end="")
        s-=1
        print()