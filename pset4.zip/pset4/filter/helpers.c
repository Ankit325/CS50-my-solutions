#include "helpers.h"
#include<math.h>
// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    int i,j,avg;
    for(i=0;i<height;i++)
    {
        for(j=0;j<width;j++)
        {
            avg=round((image[i][j].rgbtRed+image[i][j].rgbtBlue+image[i][j].rgbtGreen)/(float)3);
            image[i][j].rgbtRed=avg;
            image[i][j].rgbtBlue=avg;
            image[i][j].rgbtGreen=avg;
        }
    }
    return;
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    int i,j,sepiaRed,sepiaBlue,sepiaGreen;
    for(i=0;i<height;i++)
    {
        for(j=0;j<width;j++)
        {
            sepiaRed=round((.393*image[i][j].rgbtRed)+(.769*image[i][j].rgbtGreen)+(.189*image[i][j].rgbtBlue));
            if(sepiaRed>255)
                  sepiaRed=255;
            sepiaGreen=round((.349*image[i][j].rgbtRed)+(.686*image[i][j].rgbtGreen)+(.168*image[i][j].rgbtBlue));
            if(sepiaGreen>255)
                sepiaGreen=255;
            sepiaBlue=round((.272*image[i][j].rgbtRed)+(.534*image[i][j].rgbtGreen)+(.131*image[i][j].rgbtBlue));
            if(sepiaBlue>255)
                 sepiaBlue=255;
            image[i][j].rgbtRed=sepiaRed;
            image[i][j].rgbtBlue=sepiaBlue;
            image[i][j].rgbtGreen=sepiaGreen;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    int i,j,k;
    RGBTRIPLE temp;
    for(i=0;i<height;i++)
    {
        j=0;
        k=width-1;
        while(j<width && k>=0 && j<k)
        {
            temp=image[i][j];
            image[i][j]=image[i][k];
            image[i][k]=temp;
            j++;
            k--;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    int i,j,avgRed,avgBlue,avgGreen;
    for(i=0;i<height;i++)
    {
        for(j=0;j<width;j++)
        {
            if(i==0 && j==0)
            {
                avgRed=round((image[i][j+1].rgbtRed+image[i+1][j].rgbtRed+image[i+1][j+1].rgbtRed)/(float)3);
                avgGreen=round((image[i][j+1].rgbtGreen+image[i+1][j].rgbtGreen+image[i+1][j+1].rgbtGreen)/(float)3);
                 avgBlue=round((image[i][j+1].rgbtBlue+image[i+1][j].rgbtBlue+image[i+1][j+1].rgbtBlue)/(float)3);
                 image[i][j].rgbtRed=avgRed;
                 image[i][j].rgbtGreen=avgGreen;
                 image[i][j].rgbtBlue=avgBlue;

            }
            else  if(j==0)
            {
                avgRed=round((image[i][j+1].rgbtRed+image[i+1][j].rgbtRed+image[i+1][j+1].rgbtRed+image[i-1][j].rgbtRed+image[i-1][j+1].rgbtRed)/(float)5);
                avgGreen=round((image[i][j+1].rgbtGreen+image[i+1][j].rgbtGreen+image[i+1][j+1].rgbtGreen+image[i-1][j].rgbtGreen+image[i-1][j+1].rgbtGreen)/(float)5);
                 avgBlue=round((image[i][j+1].rgbtBlue+image[i+1][j].rgbtBlue+image[i+1][j+1].rgbtBlue+image[i-1][j].rgbtBlue+image[i-1][j+1].rgbtBlue)/(float)5);
                 image[i][j].rgbtRed=avgRed;
                 image[i][j].rgbtGreen=avgGreen;
                 image[i][j].rgbtBlue=avgBlue;

            }
            else  if(j==0 && i==height-1)
            {
                avgRed=round((image[i][j+1].rgbtRed+image[i-1][j].rgbtRed+image[i-1][j+1].rgbtRed)/(float)3);
                avgGreen=round((image[i][j+1].rgbtGreen+image[i-1][j].rgbtGreen+image[i-1][j+1].rgbtGreen)/(float)3);
                 avgBlue=round((image[i][j+1].rgbtBlue+image[i-1][j].rgbtBlue+image[i-1][j+1].rgbtBlue)/(float)3);
                 image[i][j].rgbtRed=avgRed;
                 image[i][j].rgbtGreen=avgGreen;
                 image[i][j].rgbtBlue=avgBlue;

            }
             else  if(j==width-1 && i==height-1)
            {
                avgRed=round((image[i-1][j].rgbtRed+image[i-1][j-1].rgbtRed+image[i][j-1].rgbtRed)/(float)3);
                avgGreen=round((image[i-1][j].rgbtGreen+image[i-1][j-1].rgbtGreen+image[i][j-1].rgbtGreen)/(float)3);
                 avgBlue=round((image[i-1][j].rgbtBlue+image[i-1][j-1].rgbtBlue+image[i][j-1].rgbtBlue)/(float)3);
                 image[i][j].rgbtRed=avgRed;
                 image[i][j].rgbtGreen=avgGreen;
                 image[i][j].rgbtBlue=avgBlue;
            }
             else  if(j==width-1)
            {
                avgRed=(image[i+1][j].rgbtRed+image[i-1][j].rgbtRed+image[i-1][j-1].rgbtRed+image[i][j-1].rgbtRed+image[i+1][j-1].rgbtRed)/(float)5;
                avgGreen=(image[i+1][j].rgbtGreen+image[i-1][j].rgbtGreen+image[i-1][j-1].rgbtGreen+image[i][j-1].rgbtGreen+image[i+1][j-1].rgbtGreen)/(float)5;
                 avgBlue=(image[i+1][j].rgbtBlue+image[i-1][j].rgbtBlue+image[i-1][j-1].rgbtBlue+image[i][j-1].rgbtBlue+image[i+1][j-1].rgbtBlue)/(float)5;
                 image[i][j].rgbtRed=avgRed;
                 image[i][j].rgbtGreen=avgGreen;
                 image[i][j].rgbtBlue=avgBlue;
            }
             else  if(j==width-1 && i==0)
            {
                avgRed=(image[i+1][j].rgbtRed+image[i][j-1].rgbtRed+image[i+1][j-1].rgbtRed)/(float)3;
                avgGreen=(image[i+1][j].rgbtGreen+image[i][j-1].rgbtGreen+image[i+1][j-1].rgbtGreen)/(float)3;
                 avgBlue=(image[i+1][j].rgbtBlue+image[i][j-1].rgbtBlue+image[i+1][j-1].rgbtBlue)/(float)3;
                 image[i][j].rgbtRed=avgRed;
                 image[i][j].rgbtGreen=avgGreen;
                 image[i][j].rgbtBlue=avgBlue;
            }
            else if(i==0)
            {
                avgRed=(image[i][j+1].rgbtRed+image[i+1][j].rgbtRed+image[i+1][j+1].rgbtRed+image[i][j-1].rgbtRed+image[i+1][j-1].rgbtRed)/(float)5;
                avgGreen=(image[i][j+1].rgbtGreen+image[i+1][j].rgbtGreen+image[i+1][j+1].rgbtGreen+image[i][j-1].rgbtGreen+image[i+1][j-1].rgbtGreen)/(float)5;
                 avgBlue=(image[i][j+1].rgbtBlue+image[i+1][j].rgbtBlue+image[i+1][j+1].rgbtBlue+image[i][j-1].rgbtBlue+image[i+1][j-1].rgbtBlue)/(float)5;
                 image[i][j].rgbtRed=avgRed;
                 image[i][j].rgbtGreen=avgGreen;
                 image[i][j].rgbtBlue=avgBlue;
            }
            else if(i==height-1)
            {
                avgRed=(image[i][j+1].rgbtRed+image[i-1][j].rgbtRed+image[i-1][j+1].rgbtRed+image[i-1][j-1].rgbtRed+image[i][j-1].rgbtRed)/(float)5;
                avgGreen=(image[i][j+1].rgbtGreen+image[i-1][j].rgbtGreen+image[i-1][j+1].rgbtGreen+image[i-1][j-1].rgbtGreen+image[i][j-1].rgbtGreen)/(float)5;
                 avgBlue=(image[i][j+1].rgbtBlue+image[i-1][j].rgbtBlue+image[i-1][j+1].rgbtBlue+image[i-1][j-1].rgbtBlue+image[i][j-1].rgbtBlue)/(float)5;
                 image[i][j].rgbtRed=avgRed;
                 image[i][j].rgbtGreen=avgGreen;
                 image[i][j].rgbtBlue=avgBlue;
            }

             else
            {
                avgRed=(image[i][j+1].rgbtRed+image[i+1][j].rgbtRed+image[i+1][j+1].rgbtRed+image[i-1][j].rgbtRed+image[i-1][j+1].rgbtRed+image[i-1][j-1].rgbtRed+image[i][j-1].rgbtRed+image[i+1][j-1].rgbtRed)/(float)8;
                avgGreen=(image[i][j+1].rgbtGreen+image[i+1][j].rgbtGreen+image[i+1][j+1].rgbtGreen+image[i-1][j].rgbtGreen+image[i-1][j+1].rgbtGreen+image[i-1][j-1].rgbtGreen+image[i][j-1].rgbtGreen+image[i+1][j-1].rgbtGreen)/(float)8;
                 avgBlue=(image[i][j+1].rgbtBlue+image[i+1][j].rgbtBlue+image[i+1][j+1].rgbtBlue+image[i-1][j].rgbtBlue+image[i-1][j+1].rgbtBlue+image[i-1][j-1].rgbtBlue+image[i][j-1].rgbtBlue+image[i+1][j-1].rgbtBlue)/(float)8;
                 image[i][j].rgbtRed=avgRed;
                 image[i][j].rgbtGreen=avgGreen;
                 image[i][j].rgbtBlue=avgBlue;
            }

        }
    }
    return;
}
