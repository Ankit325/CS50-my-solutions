#include<stdio.h>
#include<string.h>
#include<cs50.h>
#include<ctype.h>

int checknum(string s)
{
    int i;
    for(i=0;i<26;i++)
    {
        if(s[i]>='0' && s[i]<='9')
        {
            return 1;
        }
    }
    return 0;
}
int checkrepeat(string s)
{
    int i,j;
    for(i=0;i<26;i++)
    {
        for(j=i+1;j<26;j++)
        {
            if(s[i]==s[j])
                 return 1;
        }
    }
    return 0;

}
int main(int argc, string argv[])
{
    int i,n,j;
    //printf("%d %c",argc,argv[1][4]);
    if(argc<2 || argc>2)
    {
           printf("Usage: ./substitution KEY\n");
           return 1;
    }
    else if(strlen(argv[1])>26 || strlen(argv[1])<26)
    {
        printf("Key must contain 26 characters.\n");
        return 1;
    }
    else if(checknum(argv[1]))
    {
        printf("key must only contain alphabetic characters\n");
        return 1;
    }
    else if(checkrepeat(argv[1]))
    {
        printf("key must not contain repeated characters\n");
        return 1;
    }
    else
    {
        string sentence=get_string("plaintext: ");
        n=strlen(sentence);
        for(i=0;i<n;i++)
        {
          if(sentence[i]>='A' && sentence[i]<='Z')
          {
              sentence[i]=toupper(argv[1][sentence[i]-'A']) ;
          }
          else if(sentence[i]>='a' && sentence[i]<='z')
          {
              sentence[i]=tolower(argv[1][sentence[i]-'a']) ;
          }
        }
        printf("ciphertext: %s\n",sentence);
    }
    return 0;
}