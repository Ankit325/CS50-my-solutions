#include<stdio.h>
#include<string.h>
int main(void)
{
 char a[100];
 int i,j,n,b[100],sum,sum1;
 printf("\nEnter card number=");
 gets(a);
 n=strlen(a);
 sum=0;
 sum1=0;
 j=n-1;
 for(i=0;i<n;i++)
 {
  b[j]=a[i]-'0';
  j--;
 }
 //for(i=0;i<n;i++){printf("\n%d",b[i]);}
 i=0;
 if(n==13 || n==15 || n==16)
 {
  while(i<n)
  {
    sum1=sum1+b[i];
   if(i<n-1)
    {
      sum=sum+(2*b[i+1])%10+(int)((2*b[i+1])/10);
    }
   i=i+2;
  }
 if((sum+sum1)%10==0)
  {
   if((n==15 && b[n-1]==3) && (b[n-2]==4 || b[n-2]==7)){
       printf("AMEX\n");
   }
   else if((n==16 && b[n-1]==5) && (b[n-2]==1||b[n-2]==2 || b[n-2]==3 || b[n-2]==4 || b[n-2]==5)){
       printf("MASTERCARD\n");
   }
   else if((n==13||n==16) && b[n-1]==4 ){
      printf("VISA\n");
   }
   else
  {
   printf("INVALID\n");
  }
  }
  else
  {
   printf("INVALID\n");
  }
 }
 else
  {
   printf("INVALID\n");
  }
 }