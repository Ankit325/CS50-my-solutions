s= input("Enter card number: ")
n=len(s)
sum2=0
sum1=0
b=[]
for c in s:
    b.insert(0,ord(c)-ord('0'))
print(b)
if(n==13 or n==15 or n==16):
    for i in range(0,len(b)):
        if(i%2==0):
            sum1=sum1+b[i];
        elif(i%2!=0):
            sum2=sum2+(2*b[i])%10+(2*b[i]//10);
    if((sum2+sum1)%10==0):
        if((n==15 and b[-1]==3) and (b[-2]==4 or b[-2]==7)):
            print("AMEX")
        elif((n==16 and b[-1]==5) and (b[-2]==1 or b[-2]==2 or b[-2]==3 or b[-2]==4 or b[-2]==5)):
            print("MASTERCARD")
        elif((n==13 or n==16) and b[-1]==4 ):
            print("VISA")
        else:
            print("INVALID")
    else:
        print("INVALID")
else:
    print("INVALID")